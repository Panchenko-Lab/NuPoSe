from tensorflow.keras.models import model_from_json
import numpy as np
sls=[]
F=open('DS.txt','r')
L=F.readlines()
F.close()
for i in range(0,len(L)):
    seq=L[i].replace('\n','')
    sls.append(seq)
print(len(sls))
from .Codes.ObtainFeatures import GetFeatures
Features=GetFeatures(sls)
json_file = open('Codes/model.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)
loaded_model.load_weights("Codes/Codes/MyMDl")
loaded_model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
PRE=loaded_model.predict(Features)
F=open('SC.txt','w')
for P in PRE:
    F.write(str(P)+'\n')
F.close()