F=open('Example1.txt','r')
L=F.readlines()
F.close()
seq=''
for D in L:
    seq=seq+D
se=seq.split('>')
sls=[]
hls=[]
for i in range(1,len(se)):
    s=se[i].split("\n")
    hls.append(s[0].replace('\n','').replace('\r',''))
    S=''
    for j in range(1,len(s)):
        if len(s[j])>2:
            S=S+s[j].replace('\n','').replace('\r','')
    sls.append(S.upper())
global MainPath
from CallResNuc import ResNet
from ObtainFeatures import GetFeatures
Fe=GetFeatures(sls)
Pre=ResNet(Fe)
print(Pre)