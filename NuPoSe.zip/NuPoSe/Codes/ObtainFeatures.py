def ComSeq(seq):
    s=''
    seq=seq[::-1]
    for i in range(0,len(seq)):
        if seq[i]=='A':
            s=s+'T'
        if seq[i]=='T':
            s=s+'A'
        if seq[i]=='C':
            s=s+'G'
        if seq[i]=='G':
            s=s+'C'
    return s


def SimilarityScore(F,REF1,REF2):
    F.append(0)
    F.append(0)
    return F


def CallFunc(PTR,REF,IDN,PO,dis):
    F=FeatureExtract(PTR,REF,dis)
    PO=PositionFeatures(PTR,REF,IDN,PO)
    return F,PO

def CallFuncL(PTR,REF,IDN,PO,dis):
    F=FeatureExtractL(PTR,REF,dis)
    PO=PositionFeaturesL(PTR,REF,IDN,PO)
    return F,PO

def GetF(seq):
    ls=[]
    for i in range(0,140):
        if seq[i:i+4]=='AAAA':
            ls.append(i)
    c=0
    for i in range(0,len(ls)):
        for j in range(i+1,len(ls)):
            if (abs(ls[i]-ls[j])%10==0)|(abs(ls[i]-ls[j])%11==0)|(abs(ls[i]-ls[j])%12==0):
                c=c+1
    ls=[]
    for i in range(0,140):
        if seq[i:i+4]=='CGCG':
            ls.append(i)
    c1=len(ls)
    return [c,c1]

def FeatureExtract(PTR,REF,dis):
    from statistics import stdev
    P=len(PTR)
    R=len(REF)
    ls=[]
    for i in range(0,R-P+1):
        if REF[i:i+P]==PTR:
            ls.append(abs(i-dis))
    if len(ls)==0:
        STD,TN,AVG,FLG10=-1,-1,-1,-1
    else:
        TN=len(ls)
        AVG=((sum(ls))/(len(ls)))
        STD=0
        FLG10=0
        for i in range(0,len(ls)):
            for j in range(i+1,len(ls)):
                D=abs(ls[j]-ls[i])
                if (D%10==0)|(D%11==0)|(D%12==0):
                    FLG10=FLG10+1
        if TN>1:
            STD=stdev(ls)
    return [TN,AVG,STD,FLG10,FLG10,FLG10]

def PositionFeatures(PTR,REF,dis,PT):
    P=len(PTR)
    R=len(REF)
    for i in range(0,141):
        if i<=70:
            if REF[i:i+P]==PTR:
                PT[70-i]=1
        else:
            if REF[i:i+P]==PTR:
                PT[i-70]=1
    return PT

def FeatureExtractL(PTR,REF,dis):
    from statistics import stdev
    P=len(PTR)
    R=len(REF)
    ls=[]
    for i in range(0,22):
        if REF[i:i+P]==PTR:
            ls.append(abs(i-dis))
    for i in range(178,200):
        if REF[i:i+P]==PTR:
            ls.append(abs(i-dis))
    if len(ls)==0:
        STD,TN,AVG,FLG10=-1,-1,-1,-1
    else:
        TN=len(ls)
        AVG=((sum(ls))/(len(ls)))
        STD=0
        FLG10=0
        FLG11=0
        FLG12=0
        for i in range(0,len(ls)):
            for j in range(i+1,len(ls)):
                D=abs(ls[j]-ls[i])
                if (D%10==0)|(D%11==0)|(D%12==0):
                    FLG10=FLG10+1
        if TN>1:
            STD=stdev(ls)    
    return [TN,AVG,STD,FLG10,FLG10,FLG10]

def PositionFeaturesL(PTR,REF,dis,PT):
    P=len(PTR)
    R=len(REF)
    for i in range(0,22):
        if REF[i:i+P]==PTR:
            PT[i]=1
    for i in range(178,200):
        if REF[i:i+P]==PTR:
            PT[199-i]=1
    return PT

def WriteFeatures(F):
    s=''
    global Features
    for j in range(0,len(F)):
        s=s+str(F[j])+','
    Features=Features+s

def GetFeatures(CHR):
    FS=[]
    for Chr in range(0,len(CHR)):
        PV=0
        CH=CHR[Chr]
        while len(CH)<201:
            CH='N'+CH+'N'
        CH=CH[0:201]
        FL=[78, 155, 224, 309, 325, 389, 463, 540, 609, 697, 751, 840, 928, 937, 938, 944, 983, 1159, 1171, 1187, 1313, 1322, 1323, 1329, 1368, 1541, 1618, 1682, 1695, 2003, 2067, 2080, 2230, 2284, 2298, 2307, 2388, 2571, 2607, 2696, 2773, 2930, 3045, 3081, 3208, 3222, 3231, 3238, 3292, 3392, 3469, 3481, 3497, 3620, 3636, 3760, 3777, 3854, 3969, 4155, 4162, 4215, 4547, 4600, 4771, 4858, 4992, 5075, 5243, 5433, 5471, 5779, 5882, 5918, 6157, 6200, 6259, 6301, 6303, 6310, 6422, 6633, 6723, 6831, 6928, 6962, 7081, 7346, 7505, 7675, 7815, 7886, 7950, 8035, 8051, 8090, 8149, 8207, 8347]
        FL.sort()
        for i in range(0,len(FL)):
            FL[i]=FL[i]-1
        global Features
        Features=''
        P=['A','T','C','G']
        CO=1
        dyad=100
        REF=CH[dyad-70:dyad+73]
        for a in P:
            for b in P:
                DI=[]
                for s in range(0,71):
                    DI.append(0)
                PV=PV+1
                F,DI=CallFunc(a+b,REF,70,DI,70)
                WriteFeatures(F)
                WriteFeatures(DI)
                for c in P:
                    TI=[]
                    for s in range(0,71):
                        TI.append(0)
                    PV=PV+1
                    F,TI=CallFunc(a+b+c,REF,70,TI,70)
                    WriteFeatures(F)
                    WriteFeatures(TI)
        F=[]
        F=SimilarityScore(F,REF[0:70],REF[71:141])
        WriteFeatures(F) 
        REF=CH[dyad-100:dyad+103]
        DI=[]
        TI=[]
        PV=0
        for a in P:
            for b in P:
                DI=[]
                for s in range(0,22):
                    DI.append(0)
                PV=PV+1
                F,DI=CallFuncL(a+b,REF,100,DI,100)
                WriteFeatures(F)
                WriteFeatures(DI)
                for c in P:
                    TI=[]
                    for s in range(0,22):
                        TI.append(0)
                    PV=PV+1
                    F,TI=CallFuncL(a+b+c,REF,PV,TI,100)
                    WriteFeatures(F)
                    WriteFeatures(TI)
        F=[]
        F=SimilarityScore(F,REF[0:22],REF[178:200])
        WriteFeatures(F)
        FS2=[]
        Features=Features+'N'
        Features=Features.split(',')
        for i in range(0,len(Features)-1):
            if i in FL:
                FS2.append(int(float(Features[i])))
        REF=CH[dyad-70:dyad+73]
        f=GetF(REF)
        FS2.append(int(f[0]))
        FS2.append(int(f[1]))
        FS.append(FS2)
    return FS