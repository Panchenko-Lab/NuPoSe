def LCS(S1,S2):
    import numpy as np
    MT=np.zeros([len(S1)+1,len(S2)+1])
    for i in range(1,len(S1)+1):
        for j in range(1,len(S2)+1):
            if S1[i-1]==S2[j-1]:
                MT[i][j]=MT[i-1][j-1]+3
            else:
                MT[i][j]=max(MT[i-1][j]-2,MT[i][j-1]-2,0)
    l=0
    MV=np.amax(MT)
    r=0
    c=0
    flag=1
    for i in range(0,len(S1)+1):
        for j in range(0,len(S2)+1):
            if MT[i][j]==MV:
                r=i
                c=j
                flag=0
                break
        if flag==0:
            break
    l=0
    while MT[r][c]>0:
        if MT[r][c]==MT[r-1][c-1]+3:
            r=r-1
            c=c-1
            l=l+1
        elif MT[r][c]-2==MT[r][c-1]:
            c=c-1
        else:
            r=r-1
    return np.amax(MT),l